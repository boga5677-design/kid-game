# 小小腦力樂園 v0.7.7

本版先只處理「答對沒有音效」。

## 修正內容
- 新增 App 內建 `app/src/main/res/raw/correct_answer.wav`。
- 不再只依賴 Android `ToneGenerator.TONE_PROP_ACK`。
- 一般 8 種遊戲答對時，統一播放內建答對鈴聲。
- 英文測驗答對時補上答對鈴聲。
- 聽力挑戰答對時補上答對鈴聲。
- 單字學習按「會了」第一次獲得星星時播放答對鈴聲。
- 發音練習達高分獲得星星時播放答對鈴聲。
- 若極少數裝置無法播放 WAV，仍以 ToneGenerator 作 fallback。

## 版本
- versionCode: 30
- versionName: 0.7.7

## 簽名
沿用 v0.7.5 起的固定 GitHub Actions 簽名設定。
原本 4 個 GitHub Repository Secrets 不需要重新設定。
