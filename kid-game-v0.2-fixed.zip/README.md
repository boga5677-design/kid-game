# 小小腦力樂園 v0.2

適合 5–7 歲幼童的 Android 學習遊戲。

## v0.2 修正
- 修正各遊戲頁點擊判定，選項命中區固定，不再因重繪變動。
- 新增獨立主頁面與遊戲選單。
- 主視覺加入熊熊、黑糖、偶貴三位去背毛孩小老師。
- 進入每一題後停頓約 0.5 秒，自動以中文 TTS 朗讀題目。
- 每個遊戲頁右上角新增「重播」按鈕。
- 修正 Java/Kotlin JVM target，統一使用 Java 17。
- GitHub Actions 使用 Gradle 8.7 直接建置 APK，不依賴 gradlew。

GitHub Actions 成功後可在 Artifacts 下載 `kid-game-v0.2-debug-apk`。
