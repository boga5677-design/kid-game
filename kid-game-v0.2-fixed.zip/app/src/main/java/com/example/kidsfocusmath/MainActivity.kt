package com.example.kidsfocusmath

import android.content.Context
import android.graphics.*
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.view.MotionEvent
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale
import kotlin.math.*
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(KidsGameView(this))
    }
}

private enum class Screen {
    HOME, MENU, FIND, SAME, COLOR_SHAPE, MAZE, MATCH, COUNT, MATH, MEMORY
}

private data class Bubble(
    val x: Float,
    val y: Float,
    val r: Float,
    val kind: Int,
    val color: Int
)

private data class MenuItem(
    val title: String,
    val subtitle: String,
    val target: Screen,
    val color: Int
)

class KidsGameView(context: Context) : View(context), TextToSpeech.OnInitListener {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tone = ToneGenerator(AudioManager.STREAM_MUSIC, 72)
    private val handler = Handler(Looper.getMainLooper())
    private val tts = TextToSpeech(context, this)

    private var ttsReady = false
    private var screen = Screen.HOME
    private var stars = 0
    private var message = "今天也一起動動腦！"
    private var difficulty = 1
    private var questionText = ""

    private val homeStartRect = RectF()
    private val backRect = RectF()
    private val replayRect = RectF()
    private val menuRects = mutableListOf<Pair<RectF, Screen>>()
    private val answerRects = mutableListOf<Pair<RectF, Int>>()

    private val bubbles = mutableListOf<Bubble>()
    private var targetKind = 0
    private var targetCount = 0
    private var foundCount = 0

    private var sameCorrectIndex = 0
    private var matchSelected = -1

    private var countTarget = 5
    private var countOptions = listOf(4, 5, 6)

    private var mathA = 2
    private var mathB = 3
    private var mathOp = "+"
    private var mathAnswer = 5
    private var mathOptions = listOf(4, 5, 6)

    private var memorySequence = mutableListOf<Int>()
    private var memoryInput = mutableListOf<Int>()
    private var memoryShowing = false
    private var memoryStart = 0L

    private var mazePlayer = PointF(0f, 0f)
    private var mazeGoal = PointF(0f, 0f)
    private val mazeWalls = mutableListOf<RectF>()

    private val menuItems = listOf(
        MenuItem("找一找", "專注搜尋", Screen.FIND, 0xFFFFE4E4.toInt()),
        MenuItem("找一樣", "觀察細節", Screen.SAME, 0xFFE5F3FF.toInt()),
        MenuItem("顏色圖形", "顏色與形狀", Screen.COLOR_SHAPE, 0xFFFFF0C9.toInt()),
        MenuItem("迷宮", "手眼協調", Screen.MAZE, 0xFFE8F5E9.toInt()),
        MenuItem("配對遊戲", "找出一對", Screen.MATCH, 0xFFF2E7F5.toInt()),
        MenuItem("數一數", "數量概念", Screen.COUNT, 0xFFE0F2F1.toInt()),
        MenuItem("數學小高手", "基本加減法", Screen.MATH, 0xFFFFE3C2.toInt()),
        MenuItem("記憶挑戰", "短期記憶", Screen.MEMORY, 0xFFECE8F8.toInt())
    )

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        isFocusable = true
        isClickable = true
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale.TAIWAN)
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
            tts.setSpeechRate(0.88f)
            tts.setPitch(1.03f)
        }
    }

    override fun onDetachedFromWindow() {
        handler.removeCallbacksAndMessages(null)
        tts.stop()
        tts.shutdown()
        tone.release()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(255, 248, 238))

        when (screen) {
            Screen.HOME -> drawHome(canvas)
            Screen.MENU -> drawMenu(canvas)
            else -> {
                drawGameHeader(canvas)
                when (screen) {
                    Screen.FIND -> drawFind(canvas)
                    Screen.SAME -> drawSame(canvas)
                    Screen.COLOR_SHAPE -> drawColorShape(canvas)
                    Screen.MAZE -> drawMaze(canvas)
                    Screen.MATCH -> drawMatch(canvas)
                    Screen.COUNT -> drawCount(canvas)
                    Screen.MATH -> drawMath(canvas)
                    Screen.MEMORY -> drawMemory(canvas)
                    else -> Unit
                }
            }
        }
    }

    private fun drawHome(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()

        textPaint.textAlign = Paint.Align.CENTER
        textPaint.color = Color.rgb(79, 63, 52)
        textPaint.typeface = Typeface.DEFAULT_BOLD
        textPaint.textSize = min(58f, w * 0.075f)
        canvas.drawText("小小腦力樂園", w / 2f, 105f, textPaint)

        textPaint.typeface = Typeface.DEFAULT
        textPaint.textSize = min(28f, w * 0.040f)
        textPaint.color = Color.rgb(119, 95, 76)
        canvas.drawText("熊熊、黑糖、偶貴陪你一起學習", w / 2f, 148f, textPaint)

        // 去背主視覺：三位毛孩小老師直接畫在背景上，不使用方形底圖。
        val petY = max(300f, h * 0.34f)
        drawBearTeacher(canvas, w * 0.24f, petY, w * 0.17f)
        drawBrownSugarTeacher(canvas, w * 0.50f, petY - 8f, w * 0.17f)
        drawOguiTeacher(canvas, w * 0.76f, petY, w * 0.17f)

        textPaint.textSize = min(25f, w * 0.035f)
        textPaint.typeface = Typeface.DEFAULT_BOLD
        textPaint.color = Color.rgb(91, 72, 58)
        canvas.drawText("熊熊老師", w * 0.24f, petY + w * 0.17f + 48f, textPaint)
        canvas.drawText("黑糖老師", w * 0.50f, petY + w * 0.17f + 48f, textPaint)
        canvas.drawText("偶貴老師", w * 0.76f, petY + w * 0.17f + 48f, textPaint)

        val buttonW = w * 0.76f
        val buttonH = min(112f, h * 0.12f)
        homeStartRect.set((w - buttonW) / 2f, h - buttonH - 110f, (w + buttonW) / 2f, h - 110f)
        paint.color = Color.rgb(255, 183, 77)
        paint.setShadowLayer(12f, 0f, 6f, 0x33000000)
        canvas.drawRoundRect(homeStartRect, 38f, 38f, paint)
        paint.clearShadowLayer()

        textPaint.color = Color.rgb(74, 54, 37)
        textPaint.typeface = Typeface.DEFAULT_BOLD
        textPaint.textSize = min(38f, w * 0.052f)
        canvas.drawText("開始遊戲", homeStartRect.centerX(), homeStartRect.centerY() + 13f, textPaint)

        textPaint.typeface = Typeface.DEFAULT
        textPaint.textSize = 23f
        textPaint.color = Color.rgb(128, 103, 82)
        canvas.drawText("⭐ 已獲得 $stars 顆星星", w / 2f, h - 52f, textPaint)
        textPaint.textAlign = Paint.Align.LEFT
    }

    private fun drawMenu(canvas: Canvas) {
        val w = width.toFloat()
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.color = Color.rgb(70, 57, 48)
        textPaint.typeface = Typeface.DEFAULT_BOLD
        textPaint.textSize = min(44f, w * 0.06f)
        canvas.drawText("今天想玩哪一個？", w / 2f, 82f, textPaint)

        textPaint.typeface = Typeface.DEFAULT
        textPaint.textSize = 23f
        textPaint.color = Color.rgb(120, 98, 81)
        canvas.drawText("⭐ $stars　$message", w / 2f, 120f, textPaint)

        menuRects.clear()
        val gap = 18f
        val left = 26f
        val top = 155f
        val cardW = (w - left * 2 - gap) / 2f
        val availableH = height - top - 36f
        val cardH = min(155f, (availableH - gap * 3) / 4f)

        for (i in menuItems.indices) {
            val row = i / 2
            val col = i % 2
            val x = left + col * (cardW + gap)
            val y = top + row * (cardH + gap)
            val rect = RectF(x, y, x + cardW, y + cardH)
            paint.color = menuItems[i].color
            paint.setShadowLayer(8f, 0f, 4f, 0x22000000)
            canvas.drawRoundRect(rect, 28f, 28f, paint)
            paint.clearShadowLayer()

            textPaint.textAlign = Paint.Align.CENTER
            textPaint.color = Color.rgb(67, 55, 46)
            textPaint.typeface = Typeface.DEFAULT_BOLD
            textPaint.textSize = min(30f, cardW * 0.13f)
            canvas.drawText(menuItems[i].title, rect.centerX(), rect.centerY() - 5f, textPaint)
            textPaint.typeface = Typeface.DEFAULT
            textPaint.textSize = min(22f, cardW * 0.095f)
            textPaint.color = Color.rgb(117, 94, 75)
            canvas.drawText(menuItems[i].subtitle, rect.centerX(), rect.centerY() + 32f, textPaint)
            menuRects += RectF(rect) to menuItems[i].target
        }
        textPaint.textAlign = Paint.Align.LEFT
    }

    private fun drawGameHeader(canvas: Canvas) {
        val w = width.toFloat()
        paint.color = Color.WHITE
        paint.setShadowLayer(8f, 0f, 3f, 0x22000000)
        canvas.drawRoundRect(18f, 18f, w - 18f, 138f, 26f, 26f, paint)
        paint.clearShadowLayer()

        backRect.set(30f, 34f, 150f, 86f)
        replayRect.set(w - 150f, 34f, w - 30f, 86f)

        textPaint.textAlign = Paint.Align.CENTER
        textPaint.typeface = Typeface.DEFAULT_BOLD
        textPaint.textSize = 24f
        textPaint.color = Color.rgb(85, 68, 56)
        canvas.drawText("← 回選單", backRect.centerX(), 69f, textPaint)
        canvas.drawText("🔊 重播", replayRect.centerX(), 69f, textPaint)

        textPaint.typeface = Typeface.DEFAULT
        textPaint.textSize = min(25f, w * 0.035f)
        textPaint.color = Color.rgb(103, 83, 69)
        canvas.drawText(questionText, w / 2f, 116f, textPaint)
        textPaint.textAlign = Paint.Align.LEFT
    }

    private fun enterGame(target: Screen) {
        screen = target
        resetGameState()
        prepareGame(target)
        invalidate()
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ speakQuestion() }, 500L)
    }

    private fun prepareGame(target: Screen) {
        when (target) {
            Screen.FIND -> prepareFind()
            Screen.SAME -> prepareSame()
            Screen.COLOR_SHAPE -> prepareColorShape()
            Screen.MAZE -> prepareMaze()
            Screen.MATCH -> prepareMatch()
            Screen.COUNT -> prepareCount()
            Screen.MATH -> prepareMath()
            Screen.MEMORY -> prepareMemory()
            else -> Unit
        }
    }

    private fun speakQuestion() {
        if (!ttsReady || questionText.isBlank()) return
        tts.stop()
        tts.speak(questionText, TextToSpeech.QUEUE_FLUSH, null, "kids_question")
    }

    private fun prepareFind() {
        questionText = "請找出所有一樣的圖形。"
        val cols = 5
        val rows = 5
        val dx = width / (cols + 1f)
        val startY = 235f
        val dy = max(82f, (height - 330f) / rows)
        targetKind = Random.nextInt(0, 4)
        targetCount = 0
        foundCount = 0
        val colors = intArrayOf(0xFFF36C6C.toInt(), 0xFF4D96FF.toInt(), 0xFF64B96B.toInt(), 0xFFFFBF43.toInt())
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val kind = Random.nextInt(0, 4)
                if (kind == targetKind) targetCount++
                bubbles += Bubble(dx * (c + 1), startY + dy * r, 30f, kind, colors[kind])
            }
        }
        if (targetCount == 0) {
            bubbles[0] = bubbles[0].copy(kind = targetKind, color = colors[targetKind])
            targetCount = 1
        }
    }

    private fun symbolFor(kind: Int) = when (kind) {
        0 -> "●"
        1 -> "■"
        2 -> "▲"
        else -> "★"
    }

    private fun drawFind(canvas: Canvas) {
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.typeface = Typeface.DEFAULT_BOLD
        textPaint.textSize = 36f
        textPaint.color = Color.rgb(74, 61, 51)
        canvas.drawText("找出所有 ${symbolFor(targetKind)}", width / 2f, 190f, textPaint)
        textPaint.typeface = Typeface.DEFAULT
        textPaint.textSize = 23f
        canvas.drawText("找到 $foundCount / $targetCount", width / 2f, 220f, textPaint)
        for (b in bubbles) {
            textPaint.color = b.color
            textPaint.textSize = 58f
            canvas.drawText(symbolFor(b.kind), b.x, b.y + 19f, textPaint)
        }
        textPaint.textAlign = Paint.Align.LEFT
    }

    private fun prepareSame() {
        questionText = "請找出和左邊完全一樣的花朵。"
        sameCorrectIndex = Random.nextInt(0, 4)
    }

    private fun drawSame(canvas: Canvas) {
        val sample = RectF(36f, 230f, width * 0.38f, 440f)
        paint.color = 0xFFFFE8C8.toInt()
        canvas.drawRoundRect(sample, 26f, 26f, paint)
        drawFlower(canvas, sample.centerX(), sample.centerY(), 54f, 8, Color.rgb(235, 101, 91))

        answerRects.clear()
        val top = 220f
        val optionH = min(130f, (height - top - 50f) / 4f - 10f)
        for (i in 0 until 4) {
            val y = top + i * (optionH + 12f)
            val r = RectF(width * 0.52f, y, width - 38f, y + optionH)
            paint.color = Color.WHITE
            canvas.drawRoundRect(r, 22f, 22f, paint)
            val petals = if (i == sameCorrectIndex) 8 else listOf(6, 7, 9, 10)[i]
            drawFlower(canvas, r.centerX(), r.centerY(), min(42f, optionH * 0.35f), petals, Color.rgb(235, 101, 91))
            answerRects += RectF(r) to if (i == sameCorrectIndex) 1 else 0
        }
    }

    private fun drawFlower(canvas: Canvas, cx: Float, cy: Float, radius: Float, petals: Int, color: Int) {
        paint.color = color
        for (i in 0 until petals) {
            val a = Math.PI * 2 * i / petals
            val px = cx + cos(a).toFloat() * radius
            val py = cy + sin(a).toFloat() * radius
            canvas.drawCircle(px, py, radius * 0.34f, paint)
        }
        paint.color = 0xFFFFD166.toInt()
        canvas.drawCircle(cx, cy, radius * 0.45f, paint)
    }

    private fun prepareColorShape() {
        questionText = "請點出所有藍色的圓形。"
        val cols = 4
        val rows = 5
        val dx = width / 5f
        val dy = max(92f, (height - 300f) / rows)
        val colors = intArrayOf(0xFF4D96FF.toInt(), 0xFFFF6B6B.toInt(), 0xFF68B96B.toInt())
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                val kind = Random.nextInt(0, 2)
                val color = colors[Random.nextInt(colors.size)]
                bubbles += Bubble(dx * (c + 1), 230f + r * dy, 34f, kind, color)
            }
        }
        // 保證至少一個正確答案
        bubbles[0] = bubbles[0].copy(kind = 0, color = 0xFF4D96FF.toInt())
    }

    private fun drawColorShape(canvas: Canvas) {
        for (b in bubbles) {
            paint.color = b.color
            if (b.kind == 0) canvas.drawCircle(b.x, b.y, b.r, paint)
            else canvas.drawRoundRect(b.x - b.r, b.y - b.r, b.x + b.r, b.y + b.r, 8f, 8f, paint)
        }
    }

    private fun prepareMaze() {
        questionText = "請拖曳星星，繞過障礙走到寶箱。"
        mazePlayer = PointF(70f, 230f)
        mazeGoal = PointF(width - 75f, height - 95f)
        mazeWalls.clear()
        val w = width.toFloat()
        mazeWalls += RectF(w * 0.20f, 205f, w * 0.25f, height * 0.65f)
        mazeWalls += RectF(w * 0.40f, height * 0.38f, w * 0.45f, height - 100f)
        mazeWalls += RectF(w * 0.60f, 205f, w * 0.65f, height * 0.65f)
        mazeWalls += RectF(w * 0.80f, height * 0.38f, w * 0.85f, height - 100f)
    }

    private fun drawMaze(canvas: Canvas) {
        paint.color = 0xFF8D6E63.toInt()
        for (wall in mazeWalls) canvas.drawRoundRect(wall, 12f, 12f, paint)

        drawStar(canvas, mazePlayer.x, mazePlayer.y, 27f, 0xFFFFC107.toInt())
        drawTreasure(canvas, mazeGoal.x, mazeGoal.y, 55f)
    }

    private fun prepareMatch() {
        questionText = "請找出兩張完全相同的圖案。"
        matchSelected = -1
    }

    private fun drawMatch(canvas: Canvas) {
        answerRects.clear()
        val pairs = listOf(0, 0, 1, 2, 3, 4)
        val cardW = (width - 110f) / 2f
        val cardH = min(150f, (height - 250f) / 3f - 14f)
        for (i in pairs.indices) {
            val row = i / 2
            val col = i % 2
            val left = 40f + col * (cardW + 30f)
            val top = 220f + row * (cardH + 18f)
            val r = RectF(left, top, left + cardW, top + cardH)
            paint.color = if (i == matchSelected) 0xFFFFECB3.toInt() else Color.WHITE
            canvas.drawRoundRect(r, 24f, 24f, paint)
            drawSimpleAnimalIcon(canvas, r.centerX(), r.centerY(), min(54f, cardH * 0.36f), pairs[i])
            answerRects += RectF(r) to i
        }
    }

    private fun prepareCount() {
        countTarget = Random.nextInt(3, 11)
        countOptions = listOf(max(1, countTarget - 1), countTarget, countTarget + 1).shuffled()
        questionText = "請數一數，畫面上有幾顆蘋果？"
    }

    private fun drawCount(canvas: Canvas) {
        val cols = 4
        val startY = 235f
        for (i in 0 until countTarget) {
            val c = i % cols
            val r = i / cols
            drawApple(canvas, 100f + c * ((width - 130f) / 3f), startY + r * 95f, 31f)
        }
        answerRects.clear()
        val y = height - 150f
        val gap = 18f
        val optionW = (width - 80f - gap * 2) / 3f
        for (i in countOptions.indices) {
            val left = 40f + i * (optionW + gap)
            val rect = RectF(left, y, left + optionW, y + 92f)
            paint.color = 0xFFE3F2FD.toInt()
            canvas.drawRoundRect(rect, 22f, 22f, paint)
            textPaint.textAlign = Paint.Align.CENTER
            textPaint.color = Color.rgb(62, 67, 73)
            textPaint.typeface = Typeface.DEFAULT_BOLD
            textPaint.textSize = 38f
            canvas.drawText(countOptions[i].toString(), rect.centerX(), rect.centerY() + 13f, textPaint)
            answerRects += RectF(rect) to countOptions[i]
        }
        textPaint.textAlign = Paint.Align.LEFT
    }

    private fun prepareMath() {
        val maxNum = when (difficulty) { 1 -> 10; 2 -> 15; else -> 20 }
        mathOp = if (Random.nextBoolean()) "+" else "−"
        if (mathOp == "+") {
            mathA = Random.nextInt(1, maxNum / 2 + 1)
            mathB = Random.nextInt(1, maxNum / 2 + 1)
            mathAnswer = mathA + mathB
        } else {
            mathA = Random.nextInt(2, maxNum + 1)
            mathB = Random.nextInt(1, mathA)
            mathAnswer = mathA - mathB
        }
        val wrongA = max(0, mathAnswer - 1)
        val wrongB = mathAnswer + 1
        mathOptions = listOf(mathAnswer, wrongA, wrongB).distinct().let {
            if (it.size < 3) (it + (mathAnswer + 2)).take(3) else it
        }.shuffled()
        val opWord = if (mathOp == "+") "加" else "減"
        questionText = "請算算看，$mathA $opWord $mathB 等於多少？"
    }

    private fun drawMath(canvas: Canvas) {
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.color = Color.rgb(69, 57, 48)
        textPaint.typeface = Typeface.DEFAULT_BOLD
        textPaint.textSize = min(68f, width * 0.09f)
        canvas.drawText("$mathA  $mathOp  $mathB  =  ?", width / 2f, 310f, textPaint)

        answerRects.clear()
        for (i in mathOptions.indices) {
            val rect = RectF(70f, 395f + i * 125f, width - 70f, 490f + i * 125f)
            paint.color = 0xFFFFEFD5.toInt()
            canvas.drawRoundRect(rect, 26f, 26f, paint)
            textPaint.textSize = 42f
            canvas.drawText(mathOptions[i].toString(), rect.centerX(), rect.centerY() + 14f, textPaint)
            answerRects += RectF(rect) to mathOptions[i]
        }
        textPaint.textAlign = Paint.Align.LEFT
    }

    private fun prepareMemory() {
        memorySequence = MutableList(3 + difficulty) { Random.nextInt(0, 4) }
        memoryInput.clear()
        memoryShowing = true
        memoryStart = System.currentTimeMillis()
        questionText = "先記住亮起來的順序，等一下照順序點一次。"
        handler.postDelayed({
            memoryShowing = false
            questionText = "請照剛才的順序點顏色方塊。"
            invalidate()
            handler.postDelayed({ speakQuestion() }, 500L)
        }, 2300L)
    }

    private fun drawMemory(canvas: Canvas) {
        val centers = listOf(
            PointF(width * 0.30f, 335f),
            PointF(width * 0.70f, 335f),
            PointF(width * 0.30f, 575f),
            PointF(width * 0.70f, 575f)
        )
        val colors = intArrayOf(0xFFFF6B6B.toInt(), 0xFF4D96FF.toInt(), 0xFF64B96B.toInt(), 0xFFFFC75F.toInt())
        answerRects.clear()
        for (i in 0..3) {
            var color = colors[i]
            if (memoryShowing && memorySequence.contains(i)) color = lighten(color)
            val r = RectF(centers[i].x - 82f, centers[i].y - 82f, centers[i].x + 82f, centers[i].y + 82f)
            paint.color = color
            canvas.drawRoundRect(r, 30f, 30f, paint)
            answerRects += RectF(r) to i
        }

        textPaint.textAlign = Paint.Align.CENTER
        textPaint.typeface = Typeface.DEFAULT
        textPaint.textSize = 25f
        textPaint.color = Color.rgb(89, 72, 59)
        if (memoryShowing) {
            canvas.drawText("記住：${memorySequence.joinToString(" → ") { (it + 1).toString() }}", width / 2f, 755f, textPaint)
        } else {
            canvas.drawText("已完成 ${memoryInput.size} / ${memorySequence.size}", width / 2f, 755f, textPaint)
        }
        textPaint.textAlign = Paint.Align.LEFT
    }

    private fun resetGameState() {
        bubbles.clear()
        answerRects.clear()
        mazeWalls.clear()
        memorySequence.clear()
        memoryInput.clear()
        foundCount = 0
        matchSelected = -1
    }

    private fun success(text: String = "答對了！") {
        stars++
        message = "$text ⭐ +1"
        tone.startTone(ToneGenerator.TONE_PROP_ACK, 130)
    }

    private fun retry() {
        message = "再試一次～"
        tone.startTone(ToneGenerator.TONE_PROP_NACK, 120)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action != MotionEvent.ACTION_UP && screen != Screen.MAZE) return true
        val x = event.x
        val y = event.y

        when (screen) {
            Screen.HOME -> {
                if (event.action == MotionEvent.ACTION_UP && homeStartRect.contains(x, y)) {
                    screen = Screen.MENU
                    message = "選一個喜歡的遊戲吧！"
                    invalidate()
                    performClick()
                }
            }

            Screen.MENU -> {
                if (event.action == MotionEvent.ACTION_UP) {
                    val hit = menuRects.firstOrNull { it.first.contains(x, y) }
                    if (hit != null) {
                        enterGame(hit.second)
                        performClick()
                    }
                }
            }

            else -> {
                if (event.action == MotionEvent.ACTION_UP && backRect.contains(x, y)) {
                    tts.stop()
                    handler.removeCallbacksAndMessages(null)
                    screen = Screen.MENU
                    resetGameState()
                    invalidate()
                    performClick()
                    return true
                }
                if (event.action == MotionEvent.ACTION_UP && replayRect.contains(x, y)) {
                    speakQuestion()
                    performClick()
                    return true
                }

                when (screen) {
                    Screen.FIND -> handleFindTap(x, y)
                    Screen.SAME -> handleBinaryAnswer(x, y) { prepareSame() }
                    Screen.COLOR_SHAPE -> handleColorShapeTap(x, y)
                    Screen.MAZE -> handleMazeTouch(event)
                    Screen.MATCH -> handleMatchTap(x, y)
                    Screen.COUNT -> handleCountTap(x, y)
                    Screen.MATH -> handleMathTap(x, y)
                    Screen.MEMORY -> handleMemoryTap(x, y)
                    else -> Unit
                }
            }
        }
        return true
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    private fun handleFindTap(x: Float, y: Float) {
        val idx = bubbles.indexOfFirst { hypot((it.x - x).toDouble(), (it.y - y).toDouble()) <= it.r * 1.6 }
        if (idx < 0) return
        if (bubbles[idx].kind == targetKind) {
            bubbles.removeAt(idx)
            foundCount++
            success()
            if (foundCount >= targetCount) {
                handler.postDelayed({ enterGame(Screen.FIND) }, 650L)
            }
        } else retry()
        invalidate()
    }

    private fun handleBinaryAnswer(x: Float, y: Float, nextQuestion: () -> Unit) {
        val hit = answerRects.firstOrNull { it.first.contains(x, y) } ?: return
        if (hit.second == 1) {
            success()
            handler.postDelayed({
                resetGameState()
                nextQuestion()
                invalidate()
                handler.postDelayed({ speakQuestion() }, 500L)
            }, 450L)
        } else retry()
        invalidate()
    }

    private fun handleColorShapeTap(x: Float, y: Float) {
        val idx = bubbles.indexOfFirst { hypot((it.x - x).toDouble(), (it.y - y).toDouble()) <= it.r * 1.6 }
        if (idx < 0) return
        val b = bubbles[idx]
        if (b.kind == 0 && b.color == 0xFF4D96FF.toInt()) {
            bubbles.removeAt(idx)
            success()
            if (bubbles.none { it.kind == 0 && it.color == 0xFF4D96FF.toInt() }) {
                handler.postDelayed({ enterGame(Screen.COLOR_SHAPE) }, 650L)
            }
        } else retry()
        invalidate()
    }

    private fun handleMazeTouch(event: MotionEvent) {
        if (event.action != MotionEvent.ACTION_DOWN && event.action != MotionEvent.ACTION_MOVE && event.action != MotionEvent.ACTION_UP) return
        val x = event.x
        val y = event.y
        if (y < 155f) return
        val candidate = RectF(x - 24f, y - 24f, x + 24f, y + 24f)
        val blocked = mazeWalls.any { RectF.intersects(it, candidate) }
        if (!blocked) {
            mazePlayer.x = x.coerceIn(35f, width - 35f)
            mazePlayer.y = y.coerceIn(170f, height - 35f)
            if (hypot((mazePlayer.x - mazeGoal.x).toDouble(), (mazePlayer.y - mazeGoal.y).toDouble()) < 70.0) {
                success("找到寶箱！")
                handler.postDelayed({ enterGame(Screen.MAZE) }, 650L)
            }
            invalidate()
        }
    }

    private fun handleMatchTap(x: Float, y: Float) {
        val hit = answerRects.firstOrNull { it.first.contains(x, y) } ?: return
        val idx = hit.second
        if (matchSelected < 0) {
            matchSelected = idx
            invalidate()
            return
        }
        if (matchSelected == idx) {
            matchSelected = -1
            invalidate()
            return
        }
        val isPair = (matchSelected == 0 && idx == 1) || (matchSelected == 1 && idx == 0)
        if (isPair) {
            success()
            handler.postDelayed({ enterGame(Screen.MATCH) }, 650L)
        } else {
            retry()
            matchSelected = -1
            invalidate()
        }
    }

    private fun handleCountTap(x: Float, y: Float) {
        val hit = answerRects.firstOrNull { it.first.contains(x, y) } ?: return
        if (hit.second == countTarget) {
            success()
            handler.postDelayed({ enterGame(Screen.COUNT) }, 500L)
        } else {
            retry()
            invalidate()
        }
    }

    private fun handleMathTap(x: Float, y: Float) {
        val hit = answerRects.firstOrNull { it.first.contains(x, y) } ?: return
        if (hit.second == mathAnswer) {
            success()
            handler.postDelayed({ enterGame(Screen.MATH) }, 500L)
        } else {
            retry()
            invalidate()
        }
    }

    private fun handleMemoryTap(x: Float, y: Float) {
        if (memoryShowing) return
        val hit = answerRects.firstOrNull { it.first.contains(x, y) } ?: return
        memoryInput.add(hit.second)
        val idx = memoryInput.lastIndex
        if (memorySequence[idx] != hit.second) {
            retry()
            handler.postDelayed({ enterGame(Screen.MEMORY) }, 600L)
        } else if (memoryInput.size == memorySequence.size) {
            success("記憶成功！")
            if (difficulty < 3) difficulty++
            handler.postDelayed({ enterGame(Screen.MEMORY) }, 650L)
        }
        invalidate()
    }

    private fun lighten(color: Int): Int {
        return Color.rgb(
            min(255, Color.red(color) + 75),
            min(255, Color.green(color) + 75),
            min(255, Color.blue(color) + 75)
        )
    }

    // -------- 主視覺角色：直接以透明背景向量方式繪製 --------

    private fun drawBearTeacher(canvas: Canvas, cx: Float, cy: Float, s: Float) {
        // 熊熊：長毛吉娃娃小老師
        paint.color = 0xFFF4D2A7.toInt()
        val ear = Path().apply {
            moveTo(cx - s * 0.62f, cy - s * 0.25f)
            lineTo(cx - s * 0.25f, cy - s * 0.85f)
            lineTo(cx - s * 0.06f, cy - s * 0.18f)
            close()
        }
        canvas.drawPath(ear, paint)
        val ear2 = Path().apply {
            moveTo(cx + s * 0.62f, cy - s * 0.25f)
            lineTo(cx + s * 0.25f, cy - s * 0.85f)
            lineTo(cx + s * 0.06f, cy - s * 0.18f)
            close()
        }
        canvas.drawPath(ear2, paint)
        canvas.drawOval(cx - s * 0.60f, cy - s * 0.52f, cx + s * 0.60f, cy + s * 0.62f, paint)
        paint.color = 0xFFFFE7C7.toInt()
        canvas.drawOval(cx - s * 0.38f, cy, cx + s * 0.38f, cy + s * 0.52f, paint)
        drawPetEyes(canvas, cx, cy - s * 0.08f, s)
        paint.color = 0xFF4A352D.toInt()
        canvas.drawCircle(cx, cy + s * 0.16f, s * 0.09f, paint)
        drawTeacherBow(canvas, cx, cy + s * 0.63f, s * 0.23f, 0xFF5B8DEF.toInt())
    }

    private fun drawBrownSugarTeacher(canvas: Canvas, cx: Float, cy: Float, s: Float) {
        // 黑糖：玳瑁貓，採自然混色斑紋，不做左右半臉切色。
        paint.color = 0xFF4C3A34.toInt()
        drawCatHead(canvas, cx, cy, s)
        paint.color = 0xFFC77A39.toInt()
        canvas.drawOval(cx - s * 0.42f, cy - s * 0.34f, cx - s * 0.03f, cy + s * 0.08f, paint)
        canvas.drawOval(cx + s * 0.05f, cy + s * 0.04f, cx + s * 0.43f, cy + s * 0.38f, paint)
        paint.color = 0xFFE8A552.toInt()
        canvas.drawOval(cx - s * 0.08f, cy - s * 0.45f, cx + s * 0.22f, cy - s * 0.12f, paint)
        drawPetEyes(canvas, cx, cy - s * 0.04f, s)
        paint.color = 0xFF593B34.toInt()
        canvas.drawCircle(cx, cy + s * 0.19f, s * 0.07f, paint)
        drawTeacherBow(canvas, cx, cy + s * 0.62f, s * 0.23f, 0xFFE35D8D.toInt())
    }

    private fun drawOguiTeacher(canvas: Canvas, cx: Float, cy: Float, s: Float) {
        // 偶貴：虎斑貓小老師
        paint.color = 0xFFB79B78.toInt()
        drawCatHead(canvas, cx, cy, s)
        paint.color = 0xFF645548.toInt()
        paint.strokeWidth = s * 0.07f
        paint.style = Paint.Style.STROKE
        for (offset in listOf(-0.26f, 0f, 0.26f)) {
            canvas.drawLine(cx + s * offset, cy - s * 0.50f, cx + s * offset * 0.65f, cy - s * 0.22f, paint)
        }
        paint.style = Paint.Style.FILL
        drawPetEyes(canvas, cx, cy - s * 0.04f, s)
        paint.color = 0xFF6A5043.toInt()
        canvas.drawCircle(cx, cy + s * 0.19f, s * 0.07f, paint)
        drawTeacherBow(canvas, cx, cy + s * 0.62f, s * 0.23f, 0xFF57B99D.toInt())
    }

    private fun drawCatHead(canvas: Canvas, cx: Float, cy: Float, s: Float) {
        val leftEar = Path().apply {
            moveTo(cx - s * 0.55f, cy - s * 0.28f)
            lineTo(cx - s * 0.30f, cy - s * 0.78f)
            lineTo(cx - s * 0.07f, cy - s * 0.40f)
            close()
        }
        canvas.drawPath(leftEar, paint)
        val rightEar = Path().apply {
            moveTo(cx + s * 0.55f, cy - s * 0.28f)
            lineTo(cx + s * 0.30f, cy - s * 0.78f)
            lineTo(cx + s * 0.07f, cy - s * 0.40f)
            close()
        }
        canvas.drawPath(rightEar, paint)
        canvas.drawOval(cx - s * 0.58f, cy - s * 0.50f, cx + s * 0.58f, cy + s * 0.60f, paint)
    }

    private fun drawPetEyes(canvas: Canvas, cx: Float, cy: Float, s: Float) {
        paint.color = Color.WHITE
        canvas.drawOval(cx - s * 0.34f, cy - s * 0.13f, cx - s * 0.10f, cy + s * 0.10f, paint)
        canvas.drawOval(cx + s * 0.10f, cy - s * 0.13f, cx + s * 0.34f, cy + s * 0.10f, paint)
        paint.color = 0xFF3E302A.toInt()
        canvas.drawCircle(cx - s * 0.22f, cy, s * 0.075f, paint)
        canvas.drawCircle(cx + s * 0.22f, cy, s * 0.075f, paint)
        paint.color = Color.WHITE
        canvas.drawCircle(cx - s * 0.195f, cy - s * 0.025f, s * 0.022f, paint)
        canvas.drawCircle(cx + s * 0.245f, cy - s * 0.025f, s * 0.022f, paint)
    }

    private fun drawTeacherBow(canvas: Canvas, cx: Float, cy: Float, s: Float, color: Int) {
        paint.color = color
        val left = Path().apply { moveTo(cx, cy); lineTo(cx - s, cy - s * 0.52f); lineTo(cx - s, cy + s * 0.52f); close() }
        val right = Path().apply { moveTo(cx, cy); lineTo(cx + s, cy - s * 0.52f); lineTo(cx + s, cy + s * 0.52f); close() }
        canvas.drawPath(left, paint)
        canvas.drawPath(right, paint)
        canvas.drawCircle(cx, cy, s * 0.30f, paint)
    }

    private fun drawApple(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        paint.color = 0xFFEF5350.toInt()
        canvas.drawCircle(cx - r * 0.25f, cy, r * 0.72f, paint)
        canvas.drawCircle(cx + r * 0.25f, cy, r * 0.72f, paint)
        canvas.drawOval(cx - r * 0.62f, cy - r * 0.05f, cx + r * 0.62f, cy + r * 0.88f, paint)
        paint.color = 0xFF5D4037.toInt()
        canvas.drawRect(cx - 3f, cy - r * 0.92f, cx + 3f, cy - r * 0.55f, paint)
        paint.color = 0xFF66BB6A.toInt()
        canvas.drawOval(cx + 3f, cy - r * 0.95f, cx + r * 0.48f, cy - r * 0.62f, paint)
    }

    private fun drawSimpleAnimalIcon(canvas: Canvas, cx: Float, cy: Float, s: Float, kind: Int) {
        val colors = intArrayOf(0xFFD8A46F.toInt(), 0xFF8D8D8D.toInt(), 0xFFF2B5C8.toInt(), 0xFFE0A75E.toInt(), 0xFFB9A0D5.toInt())
        paint.color = colors[kind.coerceIn(colors.indices)]
        canvas.drawCircle(cx, cy, s, paint)
        canvas.drawCircle(cx - s * 0.65f, cy - s * 0.75f, s * 0.34f, paint)
        canvas.drawCircle(cx + s * 0.65f, cy - s * 0.75f, s * 0.34f, paint)
        drawPetEyes(canvas, cx, cy - s * 0.10f, s)
        paint.color = 0xFF4D3B32.toInt()
        canvas.drawCircle(cx, cy + s * 0.20f, s * 0.10f, paint)
    }

    private fun drawStar(canvas: Canvas, cx: Float, cy: Float, radius: Float, color: Int) {
        val p = Path()
        for (i in 0 until 10) {
            val a = -Math.PI / 2 + i * Math.PI / 5
            val r = if (i % 2 == 0) radius else radius * 0.45f
            val x = cx + cos(a).toFloat() * r
            val y = cy + sin(a).toFloat() * r
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
        paint.color = color
        canvas.drawPath(p, paint)
    }

    private fun drawTreasure(canvas: Canvas, cx: Float, cy: Float, s: Float) {
        paint.color = 0xFF8D5A2B.toInt()
        canvas.drawRoundRect(cx - s * 0.65f, cy - s * 0.38f, cx + s * 0.65f, cy + s * 0.45f, 10f, 10f, paint)
        paint.color = 0xFFFFC44D.toInt()
        canvas.drawRect(cx - s * 0.08f, cy - s * 0.38f, cx + s * 0.08f, cy + s * 0.45f, paint)
        canvas.drawCircle(cx, cy + s * 0.05f, s * 0.10f, paint)
    }
}
